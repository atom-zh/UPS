UPS
===

This is the repository for my Switch Mode Power Supply modules & UPS schematic/PCB files.

Schematic tool: Eagle CAD 6.5.0
3D modelling: Sketchup 14.1 2014

Due to components availability, UPS design is provided as is.

Project page:
https://hackaday.io/project/2145-smps-replacement-for-7805
https://hackaday.io/project/5741-emergency-backup-power-and-wallwarts-eliminator

Licensing:
Schematic: Creative Commons 4.0 Attribution-ShareAlike 4.0 International
PCB & Layout: Creative Commons 4.0 Attribution-NonCommercial
3D modelling: Creative Commons 4.0 Attribution-ShareAlike 4.0 International

Creative Commons 4.0 Attribution-NonCommercial:
See http://creativecommons.org/licenses/by-nc/4.0/

Creative Commons 4.0 Attribution-ShareAlike 4.0 International
See http://creativecommons.org/licenses/by-sa/4.0/

